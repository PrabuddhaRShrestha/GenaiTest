<!DOCTYPE html>
<html>
<head>
	<title>..::Boominathan Demo Codeigniter Project::..</title> 
	<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>	
	
	
<script src="<?php echo base_url();?>assets/javascripts/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/javascripts/1.2.1/bootstrap.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="<?php echo base_url();?>assets/javascripts/jquery.dataTables.min.js"></script>
</head>
<body>
<style type="text/css">
	b
	{
		font-size: 35px;
		font-family: gothic;

	}
</style>
<nav class="navbar navbar-default navbar-fixed-top">
 <div class="container">
 <a class="navbar-brand" href="#">Demo Project </a>
	<a href="<?php echo base_url();?>student" class="navbar-link btn btn-default navbar-btn">Add Student </a>

	<a href="<?php echo base_url();?>student/list_students " class="navbar-link btn btn-default navbar-btn ">List of Students</a>
	<a href="<?php echo base_url();?>home/logout" class="navbar-link btn btn-default navbar-btn">Logout</a>
	</div>
</nav>
<br><br><br>